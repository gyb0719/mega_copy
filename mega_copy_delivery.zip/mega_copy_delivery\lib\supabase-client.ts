// Export supabase client from main supabase.ts file
export { supabase, type Database } from './supabase';